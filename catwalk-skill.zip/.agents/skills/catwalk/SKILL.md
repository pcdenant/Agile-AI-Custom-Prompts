---
name: catwalk
description: Builds a "catwalk view" of one team's flow from Jira (live, via the Atlassian MCP) - where work sits, how long it waits, how capacity splits across the four types of work (business projects, internal projects, operational changes, unplanned work), the wastes and the gains on the table - as one interactive HTML report plus a findings note and a snapshot for comparison over time. Use it when the coach asks to see, diagnose or "catwalk" a team's flow, work distribution, lead time, cycle time, WIP, inventory, waste, unplanned work, defect drift or dependencies for a Jira project or board.
triggers: ["user"]
---

# Catwalk

You are helping an Agile coach with an operations (COO-style) mandate see a team's whole system at a glance, as if from a catwalk above a factory floor: the inventory at each station, the time it waits, where the capacity goes, and what that costs. The report must survive scrutiny from a VP, so every number has to be reproducible and traceable back to Jira.

The single most important design choice in this skill: **you never compute the metrics yourself.** You extract and classify the data; a fixed template computes everything (medians, P85, ages, gains) and a build script runs data checks before anything is delivered. This is what makes numbers identical from one team to the next and defensible in front of executives.

## Inputs

Ask only for what you cannot find yourself:
- Jira project key (required), and the board if the project has several
- Team name as it should appear on the report
- Window: 90 days unless the coach says otherwise
- Optional: average cost per person-day (only then may gains be expressed in money)

Everything is written in English.

## Workflow

### 1. Extract the data (Atlassian MCP)

Read `references/extraction.md` and follow it. In short: find the site URL, read the board configuration, list the tickets with JQL, then pull each ticket's changelog with `listJiraIssueChangelogs` (the JQL search does not return changelogs). Keep raw data in a temp folder **outside the repository**: it contains real names.

If the changelog cannot be retrieved, stop and tell the coach. Without status history there is no cycle time, no waiting time and no inventory age, and the report would be misleading.

### 2. Profile and propose the rules

Read `references/classification.md`. From what the data actually contains (issue types, labels, epics, link types, statuses, board columns), propose:
- a rule for each of the four work types, written both as a JQL filter and as a machine-readable `match` clause,
- the class of every status (queue, wait, active, blocked, done, discarded) and the flow order,
- how blocking teams and defect links are read.

Rules differ from team to team. Never reuse another team's rules without checking them against this team's data.

### 3. Checkpoint: stop and wait for approval

Show the coach the proposal in the format given in `references/classification.md` (counts, example keys, unclassified share, overlaps, open questions). **Do not build anything until the coach replies with an explicit approval.** If the classification is wrong, every number downstream is wrong, so this is the step that protects the coach's credibility. Apply any correction and show the tables again if the change is not trivial.

### 4. Write the data file

Write `data.json` following `references/data-schema.md` exactly. Privacy rules, because the report will circulate inside the company:
- Assignees become `Person A`, `Person B`... The mapping lives only in memory or in the temp folder, never in the repository.
- No titles, descriptions, comments or emails. The ticket key and the "Open in Jira" links are enough: Jira enforces its own access rights.
- Record the approval: `rules.approvedBy` and `rules.approvedAt`.

### 5. Build the report

```bash
node scripts/build_report.js /tmp/catwalk-<PROJECT>/data.json reports/<team-slug>/<YYYY-MM-DD>/
```

The script validates the schema, runs the template's own engine and the data checks in Node, and writes `report.html` and `snapshot.json`. It also compares with the most recent earlier snapshot for the same team.

- Exit 0: continue.
- Exit 1: the data file is invalid. Fix the extraction and rebuild.
- Exit 2: data checks failed. The report shows "Verdict withheld". Do not write findings. Tell the coach which checks failed and what you think the cause is (most often a segmentation overlap or an unclassified status), fix, and rebuild.

### 6. Write the findings note

Write `reports/<team-slug>/<YYYY-MM-DD>/findings.md` with the template in `references/findings-template.md`. Every number in it is copied from `snapshot.json`. Do not round differently, recompute or estimate: if a number you want is not in the snapshot, leave it out and say so. Carry the data status labels (Validated, Directional, Not yet measured) next to the numbers.

### 7. Deliver

Commit only `report.html`, `findings.md` and `snapshot.json` to the skills repository. Delete the temp folder. Then give the coach, in a few lines: the verdict sentence, the top three wastes with their gains, the checks result, and the path of the report.

## What the report contains (for reference when answering questions)

Verdict, a filter by work type (everything recalculates, except the capacity bar which always shows the whole team), key metrics, the floor (inventory per station as ticket-days stuck plus Little's Law wait), the time ledger, waste and gains ranked by days saved, dependencies, load per person (anonymized), data rules with Jira links, and a collapsible "Methods and definitions" panel. Every number has a "?" with its definition, rule, JQL and the ticket keys behind it. The data checks panel sits at the top.

## Testing without Jira

`node scripts/make_sample_data.js /tmp/sample.json [--rename] [--break]` writes synthetic data in the same schema. Use it to check the build works before a real run, or to show the coach what the report looks like.
