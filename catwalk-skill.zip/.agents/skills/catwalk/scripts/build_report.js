#!/usr/bin/env node
// Catwalk report builder.
// Usage: node build_report.js <data.json> <outDir>
// 1. Validates the data file against the schema (references/data-schema.md)
// 2. Runs the template's own engine and data checks in Node (same code as the browser page)
// 3. Writes <outDir>/report.html and <outDir>/snapshot.json
// 4. Compares with the most recent earlier snapshot in the same team folder, if any
// Exit codes: 0 = all checks passed, 1 = invalid input, 2 = data checks failed (report still written, verdict withheld)
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const [,, dataPath, outDir] = process.argv;
if (!dataPath || !outDir) { console.error('Usage: node build_report.js <data.json> <outDir>'); process.exit(1); }

const TEMPLATE = path.join(__dirname, '..', 'assets', 'catwalk-template.html');
const PLACEHOLDER = '<script id="catwalk-data" type="application/json">"__CATWALK_DATA__"</script>';

/* ---------- 1. Schema validation ---------- */
let D;
try { D = JSON.parse(fs.readFileSync(dataPath, 'utf8')); }
catch (e) { console.error('INVALID: cannot parse JSON: ' + e.message); process.exit(1); }

const errors = [];
const need = (cond, msg) => { if (!cond) errors.push(msg); };
need(D.meta && typeof D.meta === 'object', 'meta missing');
if (D.meta) {
  ['team','project','jiraBase','now','extractedAt','source'].forEach(k => need(typeof D.meta[k] === 'string' && D.meta[k], `meta.${k} missing`));
  need(Number.isInteger(D.meta.windowDays) && D.meta.windowDays >= 14, 'meta.windowDays must be an integer >= 14');
  need(!isNaN(Date.parse(D.meta.now)), 'meta.now is not a date');
}
need(D.rules && typeof D.rules === 'object', 'rules missing');
const CLASSES = ['queue','wait','active','blocked','done','discarded'];
if (D.rules) {
  need(Array.isArray(D.rules.workTypes) && D.rules.workTypes.length === 4, 'rules.workTypes must list exactly 4 work types');
  (D.rules.workTypes || []).forEach((w, i) => {
    need(['biz','int','chg','unp'].includes(w.key), `workTypes[${i}].key must be biz, int, chg or unp`);
    ['name','rule','jql'].forEach(k => need(typeof w[k] === 'string' && w[k], `workTypes[${i}].${k} missing`));
    need(Array.isArray(w.match) && w.match.length, `workTypes[${i}].match must be a non-empty array of clauses`);
  });
  need(new Set((D.rules.workTypes || []).map(w => w.key)).size === 4, 'workTypes keys must be unique');
  need(D.rules.unclassified && D.rules.unclassified.rule && D.rules.unclassified.jql, 'rules.unclassified needs rule and jql');
  need(Array.isArray(D.rules.statuses) && D.rules.statuses.length, 'rules.statuses missing');
  (D.rules.statuses || []).forEach((s, i) => need(typeof s.s === 'string' && CLASSES.includes(s.cls), `statuses[${i}] needs s and a cls in ${CLASSES.join('/')}`));
  need(Array.isArray(D.rules.flow) && D.rules.flow.length, 'rules.flow missing');
  const known = new Set((D.rules.statuses || []).map(s => s.s));
  (D.rules.flow || []).forEach(s => need(known.has(s), `flow status "${s}" is not in rules.statuses`));
  need(typeof D.rules.approvedBy === 'string' && D.rules.approvedBy, 'rules.approvedBy missing: the coach must approve the rules before building');
  need(!isNaN(Date.parse(D.rules.approvedAt)), 'rules.approvedAt missing');
}
need(Array.isArray(D.tickets) && D.tickets.length, 'tickets missing');
const keyRe = /^[A-Z][A-Z0-9_]*-\d+$/;
const personRe = /^Person [A-Z]{1,2}$/;
(D.tickets || []).forEach((t, i) => {
  if (errors.length > 30) return;
  const id = t && t.k ? t.k : `tickets[${i}]`;
  need(typeof t.k === 'string' && keyRe.test(t.k), `${id}: k must be a Jira key`);
  need(t.t === null || ['biz','int','chg','unp'].includes(t.t), `${id}: t must be biz, int, chg, unp or null`);
  need(typeof t.jt === 'string', `${id}: jt (issue type) missing`);
  need(Array.isArray(t.lb), `${id}: lb must be an array`);
  need(Number.isFinite(t.c), `${id}: c (created, epoch ms) missing`);
  need(Array.isArray(t.h) && t.h.length && t.h.every(x => Array.isArray(x) && typeof x[0] === 'string' && Number.isFinite(x[1])), `${id}: h must be [[status, epoch ms], ...]`);
  need(t.a === null || (typeof t.a === 'string' && personRe.test(t.a)), `${id}: a must be "Person X" or null (never a real name)`);
  need(Number.isInteger(t.ho) && t.ho >= 0, `${id}: ho (handoffs) must be an integer`);
  need(Array.isArray(t.ln), `${id}: ln must be an array`);
  ['summary','title','description','assigneeName','email'].forEach(k => need(!(k in t), `${id}: field "${k}" is not allowed (privacy)`));
});
if (errors.length) { console.error('INVALID DATA FILE:\n- ' + errors.slice(0, 30).join('\n- ')); process.exit(1); }

/* ---------- 2. Inject and run the template engine in Node ---------- */
const tpl = fs.readFileSync(TEMPLATE, 'utf8');
if (!tpl.includes(PLACEHOLDER)) { console.error('Template placeholder not found'); process.exit(1); }
const json = JSON.stringify(D).replace(/</g, '\\u003c');
const html = tpl.replace(PLACEHOLDER, () => '<script id="catwalk-data" type="application/json">' + json + '</script>');

const mainScript = [...tpl.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]).pop();
const els = {};
const el = id => els[id] || (els[id] = { id, textContent: id === 'catwalk-data' ? json : '', innerHTML: '', style: {}, dataset: {}, onclick: null, addEventListener() {} });
const sandbox = { document: { getElementById: el, querySelector: () => el('_q'), querySelectorAll: () => [], addEventListener() {} }, console };
vm.createContext(sandbox);
const r1 = n => Number.isFinite(n) ? Math.round(n * 10) / 10 : null;
const r3 = n => Number.isFinite(n) ? Math.round(n * 1000) / 1000 : null;
vm.runInContext(mainScript + `
;globalThis.__result = (() => {
  const checks = runChecks();
  const views = {};
  ['all', ...TYPE_KEYS, 'unc'].forEach(k => {
    const M = compute(k);
    if (!M.S.length) return;
    views[k] = {
      name: k==='all' ? 'All work' : k==='unc' ? 'Unclassified' : WT[k].name,
      finished: M.n, dataStatus: M.n >= 30 ? 'Validated' : 'Directional',
      leadP50: M.leadP50, leadP85: M.leadP85, cycleP50: M.cycP50, cycleP85: M.cycP85,
      throughputPerWeek: M.thr, inProgress: M.wip.length, aged: M.aged.length, agedKeys: M.aged.map(t=>t.k),
      waitShare: M.waitShare, flowEfficiency: M.flowEff,
      capacityShare: k==='all' ? null : capShare(k),
      stations: M.stations.map(s => ({status: s.s, cls: s.cls, tickets: s.n, ticketDaysStuck: s.stock, waitForNextTicketDays: s.drain})),
      cycleDaysByStatus: Object.fromEntries(Object.entries(M.statusDays).map(([s,d]) => [s, M.n ? d/M.n : null])),
      defects: { mode: M.defectMode, first4w: M.defFirst, last4w: M.defLast, trendClaimable: M.defSample, total: M.defTotal, linked: M.defectKeys.length, unlinked: k==='all' ? M.unlinkedKeys.length : null },
      reworkShare: M.reworkShare, handoffsP50: M.handP50, handoffs2plusShare: M.hand2,
      blockedShare: M.blockedShare, blockedDays: M.blockedDays, blockingTeams: M.teams.slice(0,3).map(([t,v]) => ({team: t, tickets: v.n, days: v.days})),
      peopleAbove4InProgress: M.overloaded, people: M.people.length,
      gains: { biggestWaitStatus: M.gWaitStatus, cycleP85IfHalved: M.gWait, cycleP85IfBlockingHalved: M.gBlocked, capacityFreedIfUnplannedAt25: k==='all' ? Math.max(0, capShare('unp') - 0.25) : null }
    };
  });
  const capacity = Object.fromEntries([...TYPE_KEYS, 'unc'].map(k => [k, capShare(k)]));
  const agedThresholds = Object.fromEntries(Object.entries(TYPE_P85).map(([k,v]) => [k, {p85: v.p85, basedOn: v.n}]));
  return { checks, views, capacity, agedThresholds, window: { start: fmtD(START), end: fmtD(NOW), days: WIN } };
})();`, sandbox, { timeout: 30000 });
const R = sandbox.__result;

/* round numbers for a readable snapshot */
const roundDeep = o => Array.isArray(o) ? o.map(roundDeep) : (o && typeof o === 'object') ? Object.fromEntries(Object.entries(o).map(([k, v]) => [k, roundDeep(v)])) : (typeof o === 'number' ? (Math.abs(o) < 1.5 && !Number.isInteger(o) ? r3(o) : r1(o)) : o);

const hard = R.checks.filter(c => c.group !== 'Sample size');
const failed = hard.filter(c => !c.pass);
const snapshot = roundDeep({
  team: D.meta.team, project: D.meta.project, generatedAt: new Date().toISOString(), extractedAt: D.meta.extractedAt,
  window: R.window, ticketCount: D.tickets.length,
  rules: {
    approvedBy: D.rules.approvedBy, approvedAt: D.rules.approvedAt,
    workTypes: D.rules.workTypes.map(w => ({ key: w.key, name: w.name, rule: w.rule, tickets: D.tickets.filter(t => t.t === w.key).length })),
    unclassified: D.tickets.filter(t => !t.t).length
  },
  checks: { status: failed.length ? 'FAILED' : 'PASSED', passed: hard.length - failed.length, total: hard.length,
            failed: failed.map(c => ({ check: c.name, detail: c.detail })), sampleSizeWarnings: R.checks.filter(c => c.warn).map(c => c.name) },
  capacityShare: R.capacity, agedThresholdsDays: R.agedThresholds, views: R.views
});

/* ---------- 3. Compare with the previous snapshot of this team ---------- */
const teamDir = path.dirname(path.resolve(outDir));
const here = path.basename(path.resolve(outDir));
let previous = null;
if (fs.existsSync(teamDir)) {
  const prev = fs.readdirSync(teamDir).filter(d => d < here && fs.existsSync(path.join(teamDir, d, 'snapshot.json'))).sort().pop();
  if (prev) previous = { folder: prev, data: JSON.parse(fs.readFileSync(path.join(teamDir, prev, 'snapshot.json'), 'utf8')) };
}
if (previous && previous.data.views && previous.data.views.all) {
  const a = snapshot.views.all, b = previous.data.views.all;
  const keys = ['leadP85','cycleP85','throughputPerWeek','inProgress','aged','waitShare','blockedShare','reworkShare'];
  snapshot.sinceLastRun = { previous: previous.folder, changes: Object.fromEntries(keys.map(k => [k, { before: b[k], now: a[k] }])),
    defectRate: { before: b.defects && b.defects.last4w, now: a.defects.last4w }, capacityUnplanned: { before: previous.data.capacityShare && previous.data.capacityShare.unp, now: snapshot.capacityShare.unp } };
}

fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'report.html'), html);
fs.writeFileSync(path.join(outDir, 'snapshot.json'), JSON.stringify(snapshot, null, 2));

console.log(`Report:   ${path.join(outDir, 'report.html')}`);
console.log(`Snapshot: ${path.join(outDir, 'snapshot.json')}`);
console.log(`Checks:   ${snapshot.checks.passed}/${snapshot.checks.total} passed` + (snapshot.checks.sampleSizeWarnings.length ? `, ${snapshot.checks.sampleSizeWarnings.length} sample-size warnings` : ''));
if (previous) console.log(`Compared with previous run: ${previous.folder}`);
if (failed.length) {
  console.error('DATA CHECKS FAILED (verdict withheld in the report):\n- ' + failed.map(c => `${c.name}${c.detail ? ': ' + c.detail : ''}`).join('\n- '));
  process.exit(2);
}
