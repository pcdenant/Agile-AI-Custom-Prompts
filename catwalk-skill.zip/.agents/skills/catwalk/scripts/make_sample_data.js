// Generates a SYNTHETIC data file in the catwalk schema, for testing the build script and the template.
// Usage: node make_sample_data.js <out.json> [--rename] [--break]
//   --rename  uses different status names (proves nothing depends on the sample team's workflow)
//   --break   makes one ticket match two work-type rules (the build must fail its checks)
const fs = require('fs');
const path = require('path');

function rng(seed){return function(){seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const R = rng(42);
const gauss = () => { let u=0,v=0; while(!u)u=R(); while(!v)v=R(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v); };
const logn = (m, s=0.7) => m*Math.exp(s*gauss());
const pick = (arr, w) => { const s=w.reduce((a,b)=>a+b,0); let r=R()*s; for(let i=0;i<arr.length;i++){ if((r-=w[i])<=0) return arr[i]; } return arr[arr.length-1]; };

const DAY = 864e5;
const NOW = Date.parse('2026-11-10T22:00:00Z');
const PEOPLE = ['Person A','Person B','Person C','Person D','Person E','Person F','Person G'];
const EXT = ['Payments team','Identity team','Data Platform','Security review'];

const tickets = [];
let key = 1100;
for (let d = 130; d >= 1; d--) {
  const n = Math.round(1.1 + R()*1.8);
  for (let k = 0; k < n; k++) {
    const drift = (130-d)/130;
    let t = pick(['biz','int','chg','unp','unc'], [0.34,0.13,0.17,0.30+0.30*drift,0.04]);
    const created = NOW - d*DAY + R()*DAY*0.9;
    const unp = t==='unp';
    let jt, lb=[], ep=null;
    if (t==='biz'){ jt='Story'; ep=pick(['ATL-900','ATL-901'],[3,2]); }
    else if (t==='int'){ jt='Task'; lb=[pick(['tech-debt','platform'],[1,1])]; }
    else if (t==='chg'){ jt=pick(['Change Request','Task'],[3,1]); lb=['config']; }
    else if (t==='unp'){ jt=pick(['Bug','Incident'],[3,2]); lb=['prod']; }
    else { jt='Task'; }
    const segs = [];
    segs.push(['Backlog', unp ? logn(0.4) : logn(t==='int'?18:t==='chg'?4:10)]);
    segs.push(['Ready', unp ? logn(0.3) : logn(4)]);
    segs.push(['In Progress', (!unp && R()<0.09) ? logn(28,0.4) : logn(unp?2.2:2.4)]);
    let b = null;
    if (!unp && R()<0.2){ b = pick(EXT,[5,3,2,2]); segs.push(['Blocked', logn(6,0.5)]); segs.push(['In Progress', logn(1)]); }
    segs.push(['Code Review', logn(unp?0.8:3)]);
    segs.push(['QA', logn(unp?1.2:1.8)]);
    if (R() < (unp?0.08:0.16)){ segs.push(['In Progress', logn(1.5)]); segs.push(['Code Review', logn(1.5)]); segs.push(['QA', logn(1)]); }
    segs.push(['Waiting for Deploy', unp ? logn(0.5) : logn(5,0.5)]);
    const h = []; let ts = created;
    for (let i = 0; i < segs.length; i++) {
      const [s, dur] = segs[i];
      h.push([s, Math.round(ts)]);
      const end = ts + dur*DAY;
      if (end > NOW) break;
      ts = end;
      if (i === segs.length-1) h.push(['Done', Math.round(ts)]);
    }
    const tk = { k:'ATL-'+(key++), t: t==='unc'? null : t, jt, lb, ep, c: Math.round(created), h,
      a: pick(PEOPLE,[5,4,4,3,3,2,2]), b, ln: [],
      ho: Math.max(0, Math.round((unp?1.4:0.8) + gauss()*0.9)) };
    tickets.push(tk);
  }
}
// defect links: a production bug is linked to an earlier ticket it came from (70% of the time)
const nonUnp = tickets.filter(x=>x.t && x.t!=='unp');
tickets.filter(x=>x.t==='unp').forEach(bug=>{
  if (R() < 0.7) {
    const pool = nonUnp.filter(x=>x.c < bug.c);
    if (!pool.length) return;
    const ty = pick(['biz','chg','int'],[5,3,2]);
    const cands = pool.filter(x=>x.t===ty);
    const src = (cands.length?cands:pool)[Math.floor(R()*(cands.length?cands:pool).length)];
    bug.ln.push(src.k);
  }
});

const DATA = {
  meta: { team:'Team Atlas', project:'ATL', jiraBase:'https://your-company.atlassian.net', windowDays:90,
          now: new Date(NOW).toISOString(), extractedAt: new Date(NOW).toISOString(), source:'SYNTHETIC sample data (make_sample_data.js)' },
  rules: {
    workTypes: [
      { key:'biz', name:'Business projects', rule:'Story that belongs to an epic', jql:'project = ATL AND issuetype = Story AND parent is not EMPTY', match:[{jt:['Story'], epic:true}], evidence:'Epics ATL-900 Claims portal, ATL-901 Renewals carry all customer-facing stories' },
      { key:'int', name:'Internal projects', rule:'Task labelled tech-debt or platform', jql:'project = ATL AND issuetype = Task AND labels in (tech-debt, platform)', match:[{jt:['Task'], labelsAny:['tech-debt','platform']}], evidence:'Labels used consistently by the team for non-customer work' },
      { key:'chg', name:'Operational changes', rule:'Change Request, or Task labelled config', jql:'project = ATL AND (issuetype = "Change Request" OR (issuetype = Task AND labels = config))', match:[{jt:['Change Request']},{jt:['Task'], labelsAny:['config']}], evidence:'Change Requests follow the CAB workflow' },
      { key:'unp', name:'Unplanned work', rule:'Bug or Incident labelled prod', jql:'project = ATL AND issuetype in (Bug, Incident) AND labels = prod', match:[{jt:['Bug','Incident'], labelsAny:['prod']}], evidence:'Label prod is set by the on-call triage' }
    ],
    unclassified: { rule:'Task with no label and no epic', jql:'project = ATL AND issuetype = Task AND labels is EMPTY AND parent is EMPTY' },
    statuses: [
      { s:'Backlog', cls:'queue' }, { s:'Ready', cls:'wait' }, { s:'In Progress', cls:'active' }, { s:'Blocked', cls:'blocked' },
      { s:'Code Review', cls:'wait' }, { s:'QA', cls:'active' }, { s:'Waiting for Deploy', cls:'wait' }, { s:'Done', cls:'done' }
    ],
    flow: ['Ready','In Progress','Blocked','Code Review','QA','Waiting for Deploy'],
    defectLinks: true,
    approvedBy: 'coach', approvedAt: new Date(NOW).toISOString()
  },
  tickets
};


const args = process.argv.slice(2);
const out = args.find(a => !a.startsWith('--'));
if (!out) { console.error('Usage: node make_sample_data.js <out.json> [--rename] [--break]'); process.exit(1); }
if (args.includes('--rename')) {
  const map = { 'Backlog':'To Do', 'Ready':'Selected', 'In Progress':'Dev', 'Blocked':'On Hold', 'Code Review':'Peer Review', 'QA':'Testing', 'Waiting for Deploy':'Ready to Release', 'Done':'Released' };
  DATA.rules.statuses.forEach(s => s.s = map[s.s]);
  DATA.rules.statuses.push({ s:"Won't Do", cls:'discarded' });
  DATA.rules.flow = DATA.rules.flow.map(s => map[s]);
  DATA.tickets.forEach(t => t.h.forEach(x => x[0] = map[x[0]]));
  // a few tickets abandoned after starting: must leave the WIP
  DATA.tickets.filter(t => t.h[t.h.length-1][0] === 'Dev').slice(0, 3).forEach(t => t.h.push(["Won't Do", Math.min(Date.parse(DATA.meta.now), t.h[t.h.length-1][1] + 864e5)]));
}
if (args.includes('--break')) {
  const t = DATA.tickets.find(x => x.t === 'int'); t.lb = ['tech-debt', 'config'];
}
fs.writeFileSync(out, JSON.stringify(DATA, null, 0));
console.log('wrote', out, 'tickets', DATA.tickets.length);
