# Proposing the rules from the data

Rules are built from what this team's Jira actually contains. Start by profiling, then propose, then show the checkpoint.

## 1. Profile

Count tickets by:
- issue type,
- issue type x label (top labels only),
- issue type x has a parent epic (and which epics),
- status (current and historical),
- link types used.

Look at a handful of ticket keys in each group (without copying titles into any file) to understand what the group holds.

## 2. The four types of work

These come from *The Phoenix Project*. Read them as questions about who asked for the work and whether it was planned:

| Key | Type | What belongs here | Typical Jira signals |
|---|---|---|---|
| `biz` | Business projects | Work requested by the business or customers, part of a planned initiative | Stories under business epics, feature requests |
| `int` | Internal projects | Improvements the team chose for itself: tech debt, platform, tooling, automation | Labels like tech-debt, platform, refactor; internal epics |
| `chg` | Operational changes | Routine planned changes to keep things running: releases, configuration, access, upgrades, maintenance | Change Request type, config or release labels, recurring tasks |
| `unp` | Unplanned work | Work that interrupts the plan: incidents, production bugs, urgent support | Bug and Incident types, prod or hotfix labels, high priority created and started the same day |

A ticket that fits none of the rules is **Unclassified**. Do not force it into a type. Aim for less than 10% unclassified; above that, say so at the checkpoint, because it usually means labelling discipline is weak, which is itself a finding.

## 3. Writing a rule

Each type gets two equivalent forms:
- `jql`: a JQL filter the coach can open in Jira,
- `match`: a list of clauses; a ticket matches the type if it matches **any** clause. A clause can test `jt` (list of issue types), `labelsAny` (list of labels, at least one present) and `epic` (true or false: has a parent epic or not). All conditions present in a clause must hold.

```json
{ "key": "chg", "name": "Operational changes", "rule": "Change Request, or Task labelled config",
  "jql": "project = ATL AND (issuetype = \"Change Request\" OR (issuetype = Task AND labels = config))",
  "match": [ { "jt": ["Change Request"] }, { "jt": ["Task"], "labelsAny": ["config"] } ],
  "evidence": "Change Requests follow the CAB workflow" }
```

Check that **no ticket matches two types**. If one does, tighten a rule (for example add `"epic": false`) rather than relying on an order of priority: the page and the build script reject overlaps. Then set each ticket's `t` by applying the rules.

The `rule` is the plain-language version the VP will read. The `evidence` says what in the data supports it.

## 4. Status classes and flow

| Class | Meaning | Examples |
|---|---|---|
| `queue` | Before commitment; not part of cycle time | Backlog, To Do, Open |
| `wait` | Committed or in flow, nobody working on it | Ready, Selected, Code Review, Waiting for Deploy, Ready to Release |
| `active` | Someone is working on it | In Progress, Dev, QA, Testing |
| `blocked` | Waiting on someone outside the team | Blocked, On Hold, Waiting for Vendor |
| `done` | Delivered | Done, Released, Closed (with a delivered resolution) |
| `discarded` | Closed without delivery; excluded from all metrics | Won't Do, Cancelled, Duplicate |

Review queues are `wait`, not `active`: the ticket is waiting for a reviewer. If the team insists a status is active, accept it and note it in the checkpoint.

`flow` is the ordered list of statuses from commitment to just before done (no queue, no done, no discarded statuses), in board column order. Cycle time starts at the first `active` status; statuses in the flow before it (like Ready) are shown as not-started inventory.

## 5. Checkpoint message

Show this to the coach, then stop and wait for an explicit approval:

```
Catwalk: proposed rules for <TEAM> (<KEY>), <N> tickets, window <start> to <end>

Work types
| Type | Rule | Tickets | Examples |
| Business projects | ... | 85 | KEY-1, KEY-2, KEY-3 |
| Internal projects | ... | ... | ... |
| Operational changes | ... | ... | ... |
| Unplanned work | ... | ... | ... |
| Unclassified | residual | 12 (5%) | KEY-9, ... |
Overlaps: none

Statuses
| Status | Class | Why |
| Code Review | wait | queue for a reviewer |
...
Flow: Ready > In Progress > Blocked > Code Review > QA > Waiting for Deploy

Links
- Blocking teams read from "is blocked by" links to other projects: <n> tickets
- Defects linked to an origin ticket: <x> of <y>

Open questions
1. ...

Reply "ok" to build the report, or correct any line.
```

Keep open questions to the ones that change the numbers (for example: "Is Testing done by the team or by a separate QA group?").
