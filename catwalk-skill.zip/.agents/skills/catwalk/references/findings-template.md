# findings.md template

Every number comes from `snapshot.json` (path given in brackets). Write in English, short sentences, no adjectives that the numbers do not support. Put the data status next to each number: Validated, Directional or Not yet measured. If the checks failed (`checks.status` is FAILED), do not write this note.

```markdown
# Catwalk: <team> (<project>), <window.start> to <window.end>

Data checks: <checks.passed>/<checks.total> passed. Rules approved by <rules.approvedBy> on <rules.approvedAt>.
<sample-size warnings, if any, in one line>

## Verdict
<One to three sentences built from views.all: waitShare, capacityShare.unp, leadP85, aged, defect drift only if views.all.defects.trendClaimable is true.>

## Key numbers (all work)
| Metric | Value | Data |
|---|---|---|
| Lead time P50 / P85 | <leadP50> / <leadP85> days | ... |
| Cycle time P50 / P85 | ... | ... |
| Throughput | <throughputPerWeek> per week | ... |
| In progress / aged | <inProgress> / <aged> | ... |
| Time spent waiting | <waitShare as %> of cycle time | ... |
| Defect rate (4 weeks) | <defects.first4w> to <defects.last4w> | ... |
| Blocked by other teams | <blockedShare as %> | ... |

## Where the capacity goes
<capacityShare per type as %, one line each, plus unclassified. One sentence on what stands out.>

## Biggest queue
<The station with the most ticketDaysStuck among wait/blocked classes: tickets, ticket-days stuck, waitForNextTicketDays.>

## Top wastes and gains
Rank by days saved on P85 cycle time (cycleP85 minus the gain value). Show at most three.
1. **<waste>**: <what the data shows>. Gain: <gain>. (<data status>)
2. ...
3. ...

## Dependencies
<blockingTeams: team, tickets, days. Gain if blocking halved.>

## By work type
<Only types whose view differs sharply from all work, one line each, with their data status. Skip if nothing stands out.>

## Since last run
<Only if sinceLastRun exists: before -> now for the key metrics, one line each.>

## Data caveats
- Unclassified: <rules.unclassified> tickets
- Unlinked defects: <views.all.defects.unlinked> of <views.all.defects.total>
- <Directional views and why>

## Experiments to consider
At most three, each tied to one waste above, each small enough to test in 48 hours to two weeks, each with the metric from this report that will show whether it worked.
```

Money: only if the coach gave a cost per person-day. Then convert capacity percentages into person-days over the window, and say it is an estimate.
