# Extracting a team's data from Jira

Goal: for every ticket that was open at some point in the window, get its type, labels, parent, links, creation date, full status history and number of assignee changes. Use the Atlassian MCP. Tool names below are those of the Atlassian Rovo MCP server; if a name differs in this environment, list the MCP tools and use the equivalent.

## 1. Site and project

- Find the site URL and cloud id with the MCP's resource lookup tool (for example `getAccessibleAtlassianResources`). The site URL becomes `meta.jiraBase` (for example `https://acme.atlassian.net`).
- Confirm the project exists with `listJiraProjects`.

## 2. Board and statuses

- `listJiraBoards` filtered on the project, then `getJiraBoardConfig` on the team's board. The column order gives the flow order and a first guess of which statuses are waiting and which are working.
- `listJiraStatuses` gives each status's category (To Do, In Progress, Done). Categories are only a starting point: a "Code Review" status is usually in category In Progress but is a waiting queue.

## 3. Ticket list

Use `searchJiraIssuesUsingJql`, paginating until the end:

```
project = <KEY> AND (statusCategory != Done OR updated >= -<windowDays + 7>d) ORDER BY created ASC
```

This keeps everything still open (whatever its age, because old open tickets are inventory) and everything that moved during the window. Request these fields: `issuetype, labels, parent, created, status, assignee, issuelinks, resolution`.

Exclude sub-tasks unless the team tracks its work at sub-task level (ask the coach at the checkpoint if sub-tasks are numerous).

## 4. Status history (changelog)

The JQL search does not return changelogs. For each ticket, call `listJiraIssueChangelogs` and page through it (oldest first). From each history entry keep:
- items whose `field` is `status`: `fromString`, `toString`, and the entry `created` timestamp,
- items whose `field` is `assignee`: count them (this becomes `ho`, the number of handoffs). Ignore the very first assignment from empty to a person.

Build `h` (the status history) like this:
1. First element: the status the ticket was created in, at the creation timestamp. That is the `fromString` of the first status change, or the current status if there was no change.
2. Then one element per status change: `[toString, timestamp in epoch milliseconds]`, in time order.

If `listJiraIssueChangelogs` is not available or returns no status items for tickets that clearly moved, stop and tell the coach: without status history the report cannot be built honestly.

Volume: one changelog call per ticket. For a few hundred tickets this is acceptable. If the coach has configured a Jira API token as a Devin secret, the REST endpoint `/rest/api/3/search/jql` with `expand=changelog` is a faster alternative; never ask for credentials in the conversation.

## 5. Links

- **Blocking team** (`b`): from `issuelinks`, a link of type "Blocks" where this ticket is the inward side ("is blocked by") and the other ticket belongs to **another project**. Use that project's name as the team name. If several, take the first one. Leave `null` otherwise. Blocked time itself comes from the statuses classed `blocked`.
- **Defect links** (`ln`): only for tickets that will be classed as unplanned work. List the keys of linked tickets (relates to, is caused by, clones, and similar; not "blocks"), plus the parent key when the parent is not an epic. These say where the defect came from.
- **References** (`refs`): for every key in `ln` that is not in the extracted ticket list, read it with `getJiraIssue` (type, labels, parent only) and apply the approved work-type rules to get its type. Store `refs: { "KEY-1": "biz", ... }`. Without this, defects pointing to older tickets would look unlinked.

## 6. Anonymization

Replace each assignee by `Person A`, `Person B`, ... in order of first appearance when tickets are sorted by key. Unassigned stays `null`. Keep the mapping only in memory or in the temp folder; it must never reach the repository or the report.

## 7. Where things go

- Raw extraction and the name mapping: `/tmp/catwalk-<KEY>/` (outside the repository). Delete it at the end of the run.
- The final `data.json`: same temp folder. It is anonymized, but it is an intermediate file, not a deliverable.
