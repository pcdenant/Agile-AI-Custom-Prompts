# data.json schema

The build script rejects any file that does not follow this. Times are epoch milliseconds (numbers), except the ISO strings in `meta` and `rules.approvedAt`.

```json
{
  "meta": {
    "team": "Team Atlas",
    "project": "ATL",
    "jiraBase": "https://acme.atlassian.net",
    "windowDays": 90,
    "now": "2026-11-10T22:00:00Z",
    "extractedAt": "2026-11-10T22:00:00Z",
    "source": "Atlassian MCP"
  },
  "rules": {
    "workTypes": [
      { "key": "biz", "name": "Business projects", "rule": "Story that belongs to an epic",
        "jql": "project = ATL AND issuetype = Story AND parent is not EMPTY",
        "match": [ { "jt": ["Story"], "epic": true } ],
        "evidence": "Epics ATL-900 and ATL-901 carry all customer-facing stories" },
      { "key": "int", "...": "..." },
      { "key": "chg", "...": "..." },
      { "key": "unp", "...": "..." }
    ],
    "unclassified": { "rule": "Anything matching no rule", "jql": "project = ATL AND NOT (...)" },
    "statuses": [ { "s": "Backlog", "cls": "queue" }, { "s": "In Progress", "cls": "active" }, { "s": "Done", "cls": "done" } ],
    "flow": ["Ready", "In Progress", "Blocked", "Code Review", "QA", "Waiting for Deploy"],
    "defectLinks": true,
    "approvedBy": "coach",
    "approvedAt": "2026-11-10T21:55:00Z"
  },
  "refs": { "ATL-850": "biz" },
  "tickets": [
    { "k": "ATL-1100", "t": "biz", "jt": "Story", "lb": [], "ep": "ATL-900",
      "c": 1754000000000,
      "h": [["Backlog", 1754000000000], ["Ready", 1754600000000], ["In Progress", 1754900000000], ["Done", 1756000000000]],
      "a": "Person A", "b": null, "ln": [], "ho": 1 }
  ]
}
```

## Fields

| Field | Meaning |
|---|---|
| `meta.now` | Extraction time. All ages are measured against it. |
| `meta.windowDays` | Window for finished tickets and capacity (default 90, minimum 14). |
| `rules.workTypes` | Exactly four entries, keys `biz`, `int`, `chg`, `unp`. `match` must be equivalent to `jql`. |
| `rules.statuses` | Every status that appears in any history, with its class: `queue`, `wait`, `active`, `blocked`, `done`, `discarded`. |
| `rules.flow` | Ordered statuses from commitment to just before done. Must contain at least one `active` status. |
| `rules.defectLinks` | `true` if defect links were extracted. |
| `rules.approvedBy/At` | Who approved the rules at the checkpoint, and when. Required. |
| `refs` | Work type of linked tickets that are outside the extraction (optional). |
| `k` | Jira key. |
| `t` | Work type key, or `null` for unclassified. Must equal the result of applying `match`. |
| `jt`, `lb`, `ep` | Issue type, labels, parent epic key (or `null`). Used to re-check the segmentation. |
| `c` | Creation time. |
| `h` | Status history: first element = creation status at creation time, then one entry per transition. |
| `a` | `Person X` or `null`. Never a real name. |
| `b` | Name of the blocking team, or `null`. |
| `ln` | For unplanned tickets: keys of the tickets the defect is linked to. Otherwise `[]`. |
| `ho` | Number of assignee changes (handoffs). |

Forbidden fields on tickets (the build rejects them): `summary`, `title`, `description`, `assigneeName`, `email`.
